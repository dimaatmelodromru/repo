/***********************
* Adobe Edge Animate Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge Animate
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

   //Edge symbol: 'stage'
   (function(symbolName) {
      
      
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 0, function(sym, e) {
         function changeText(id,from, to) {
         	val = sym.$(id).html();
         	sym.$(id).html(val.replace(from,to));
         }
         changeText('s1_title', '®','<sup>®</sup>');
         changeText('s3_title', '1','<sup>1</sup>');
         changeText('s4_title', '2','<sup>2</sup>');
         changeText('s5_title', '3','<sup>3</sup>');
         changeText('s6_title', '3','<sup>3</sup>');
         changeText('s7_title', '4','<sup>4</sup>');
         changeText('s9_title', '4','<sup>4</sup>');
         changeText('s10_title', '4','<sup>4</sup>');
         changeText('s11_title', '4','<sup>4</sup>');
         changeText('s12_title', '8','<sup>8</sup>');
         changeText('s13_title', 'R','<sup>®</sup>');
         changeText('s13_btn_underplaytext', '9','<sup>9</sup>');
         changeText('s13_btn_underplaytext2', '10','<sup>10</sup>');
         changeText('s14_title', '11','<sup>11</sup>');
         changeText('s15_title', '®','<sup>®</sup>');
         changeText('s14_target_text3', '13','<sup>13</sup>');
         changeText('s14_target_text2', '12','<sup>12</sup>');
         
         anchor.act = sym;
         anchor.playFrom = 'slide0';
         anchor.playBack = '';
         

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 4250, function(sym, e) {
         // play the timeline from the given position (ms or label)
         // play the timeline from the given position (ms or label)
         sym.stop();
         
         
         anchor.act = sym;
         anchor.playFrom = 'slide2';
         anchor.playBack = 'slide1_back';

      });
      //Edge binding end

      

      

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 6250, function(sym, e) {
         sym.stop();
         
         anchor.act = sym;
         anchor.playFrom = 'slide3';
         anchor.playBack = 'slide1_back';

      });
      //Edge binding end

      

      Symbol.bindTimelineAction(compId, symbolName, "Default Timeline", "update", function(sym, e) {
         function Loader(id, startFrame, max) {
         	var val = parseInt(sym.$(id).html());
         	var pos = sym.getPosition();
         	if (val<max && pos>=startFrame) {
         		val++; 
         		sym.$(id).html(val+'%');
         	}
         }
         Loader('s3_row_diag1_text', 8255, 73);
         Loader('s3_row_diag2_text', 8255, 60);
         Loader('s3_row2_diag3_text', 10750, 46);
         Loader('s3_row2_diag4_text', 10750, 36);
         Loader('s3_row3_diag5_text', 12795, 30);
         Loader('s3_row3_diag6_text', 12795, 18);
         Loader('s5_percent', 19250, 53);
         Loader('s5_percent2', 20500, 42);
         Loader('s5_percent3', 21750, 5);
         

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 14750, function(sym, e) {
         sym.stop();
         anchor.act = sym;
         anchor.playFrom = 'slide4';
         anchor.playBack = 'slide2_back';

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 16750, function(sym, e) {
         sym.stop();
         
         anchor.act = sym;
         anchor.playFrom = 'slide5';
         anchor.playBack = 'slide3_back';

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 22250, function(sym, e) {
         sym.stop();
         anchor.act = sym;
         anchor.playFrom = 'slide6';
         anchor.playBack = 'slide4_back';

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 24250, function(sym, e) {
         sym.stop();
         anchor.act = sym;
         anchor.playFrom = 'slide7';
         anchor.playBack = 'slide5_back';

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_s4_next_btn}", "click", function(sym, e) {
         sym.$('s4_next_btn').css({'background-image':'url(media/images/next_btn.png)'});
         sym.$('s4_title').html('В большинстве случаев<br>периодическая боль<br>приводит к нарушению<br>социальной и повседневной<br>активности');
         sym.$('s4_prev_btn').css({'background-image':'url(media/images/prev_btn_active.png)'});

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_s4_prev_btn}", "click", function(sym, e) {
         sym.$('s4_prev_btn').css({'background-image':'url(media/images/prev_btn.png)'});
         sym.$('s4_title').html('Частота возникновения<br>периодической боли<br>составляет 50 - 90%<sup>2</sup>');
         sym.$('s4_next_btn').css({'background-image':'url(media/images/next_btn_active.png)'});

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 28500, function(sym, e) {
         sym.stop();
         sym.$('s7_matka_ok').css('background-image','url(media/images/matka_ok.png)');
         anchor.act = sym;
         anchor.playFrom = 'slide8';
         anchor.playBack = 'slide6_back';

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 32500, function(sym, e) {
         sym.$('s7_matka_ok').css('background-image','url(media/images/matka_bad.gif)');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 37500, function(sym, e) {
         sym.$('s7_nervi').css('background-image','url(media/images/nerfvi_bad.gif)');
         sym.$('s7_plashka_bol').css('background-image','url(media/images/bol.gif)');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 47250, function(sym, e) {
         sym.$('s7_matka_ok').css('background-image','url(media/images/matka_good.gif)');

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_s9_drotavern_btn}", "click", function(sym, e) {
         sym.play(42000);
         sym.$('s9_drotavern_mol').css('background-image','url(media/images/drotavern_mol_blur.png)');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 42000, function(sym, e) {
         sym.$('s7_nervi').css('background-image','url(media/images/nerfvi_bad.gif)');
         sym.$('s7_plashka_bol').css('background-image','url(media/images/bol.gif)');

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_s9_repeat_btn}", "click", function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play(42000);
         sym.$('s7_matka_ok').css('background-image','url(media/images/matka_bad.png)');
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_s9_prev_btn_active}", "click", function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play(41000);
         sym.$('s7_matka_ok').css('background-image','url(media/images/matka_bad.png)');

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_s9_drotavern_mol}", "click", function(sym, e) {
         sym.play(42000);
         sym.$('s9_drotavern_mol').css('background-image','url(media/images/drotavern_mol_blur.png)');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 41000, function(sym, e) {
         sym.stop();
         anchor.act = sym;
         anchor.playFrom = 'slide9';
         anchor.playBack = 'slide7_back';

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 53250, function(sym, e) {
         sym.stop();
         sym.$('s9_drotavern_mol').css('background-image','url(media/images/drotavern_mol.png)');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 55000, function(sym, e) {
         sym.$('s7_nervi').css('background-image','url(media/images/nerfvi_bad.gif)');

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_ibuprofen_btn}", "click", function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play(55000);
         sym.$('ibuprofen_mol').css('background-image','url(media/images/ibuprofen_mol_blur.png)');
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_ibuprofen_mol}", "click", function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play(55000);
         sym.$('ibuprofen_mol').css('background-image','url(media/images/ibuprofen_mol_blur.png)');
         

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 62500, function(sym, e) {
         sym.$('s7_matka_ok').css('background-image','url(media/images/matka_good.gif)');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 66250, function(sym, e) {
         sym.$('s7_nervi').css('background-image','url(media/images/nervi.png)');

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_s10_repeat_btn}", "click", function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play(55000);
         sym.$('s7_matka_ok').css('background-image','url(media/images/matka_bad.png)');
         sym.$('s7_nervi').css('background-image','url(media/images/nerfvi_bad.gif)');

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_s10_prev_btn_active}", "click", function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play(41000);
         sym.$('s7_matka_ok').css('background-image','url(media/images/matka_bad.png)');
         sym.$('s7_nervi').css('background-image','url(media/images/nerfvi_bad.gif)');
         

      });
      //Edge binding end

      

      

      

      

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 68500, function(sym, e) {
         sym.stop();
         sym.$('ibuprofen_mol').css('background-image','url(media/images/ibuprofen_mol.png)');

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_s11_next_btn}", "click", function(sym, e) {
         if(cur_text==1) {
         	sym.$('s11_title').html('Ибупрофен признан<br>«золотым стандартом»<br>в лечении<br>периодической боли<sup>5</sup>');
         	sym.$('s11_prev_btn').css({'background-image':'url(media/images/prev_btn_active.png)'})
         	cur_text=2;
         } else if (cur_text==2) {
         	sym.$('s11_next_btn').css({'background-image':'url(media/images/next_btn.png)'});
         	sym.$('s11_title').html('Спазмолитики не являются<br>эффективным средством<br>лечения периодической боли<sup>6</sup><br>и не включены в международные<br>стандарты лечения<sup>7</sup>');
         	sym.$('s11_prev_btn').css({'background-image':'url(media/images/prev_btn_active.png)'});
         	cur_text=3;
         }

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_s11_prev_btn}", "click", function(sym, e) {
         if(cur_text==3) {
         	sym.$('s11_title').html('Ибупрофен признан<br>«золотым стандартом»<br>в лечении<br>периодической боли<sup>5</sup>');
         	sym.$('s11_prev_btn').css({'background-image':'url(media/images/prev_btn_active.png)'})
         	cur_text=2;
         } else if (cur_text==2) {
         	sym.$('s11_prev_btn').css({'background-image':'url(media/images/prev_btn.png)'});
         	sym.$('s11_next_btn').css({'background-image':'url(media/images/next_btn_active.png)'});
         	sym.$('s11_title').html('Согласно международным<br>стандартам,<br>НПВС - препараты первой<br> линии при лечении<br>периодической боли<sup>4</sup>');
         	cur_text=1;
         }

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 71000, function(sym, e) {
         sym.stop();
         cur_text = 1;
         anchor.act = sym;
         anchor.playFrom = 'slide10';
         anchor.playBack = 'slide8_back';

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 75750, function(sym, e) {
         sym.stop();
         anchor.act = sym;
         anchor.playFrom = 'slide11';
         anchor.playBack = 'slide9_back';

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 77750, function(sym, e) {
         sym.stop();
         anchor.act = sym;
         anchor.playFrom = 'slide12';
         anchor.playBack = 'slide10_back';

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_s13_btn_play}", "click", function(sym, e) {
         sym.$('s13_btn_play').animate({left: "114"},400);
         sym.$('s13_btn_Text').animate({left: "214"},400);
         sym.$('s13_btn_underplay').animate({left: "483", width:"400"},400);
         sym.$('s13_btn_underplaytext').animate({left: "552"},400);
         sym.$('s13_btn_shadow').animate({left: "125", width:"739"},400);
         sym.$('s13_play_glow').hide();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_s13_btn_play2}", "click", function(sym, e) {
         sym.$('s13_btn_play2').animate({left: "114"},400);
         sym.$('s13_btn_Text2').animate({left: "214"},400);
         sym.$('s13_btn_underplay2').animate({left: "483", width:"400"},400);
         sym.$('s13_btn_underplaytext2').animate({left: "552"},400);
         sym.$('s13_btn_shadow2').animate({left: "125", width:"739"},400);
         sym.$('s13_play_glow2').hide();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 80500, function(sym, e) {
         sym.stop();
         anchor.act = sym;
         anchor.playFrom = 'slide13';
         anchor.playBack = 'slide11_back';

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_s13_btn_Text}", "click", function(sym, e) {
         sym.$('s13_btn_play').animate({left: "114"},400);
         sym.$('s13_btn_Text').animate({left: "214"},400);
         sym.$('s13_btn_underplay').animate({left: "483", width:"400"},400);
         sym.$('s13_btn_underplaytext').animate({left: "552"},400);
         sym.$('s13_btn_shadow').animate({left: "125", width:"739"},400);
         sym.$('s13_play_glow').hide();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_s13_btn_Text2}", "click", function(sym, e) {
         sym.$('s13_btn_play2').animate({left: "114"},400);
         sym.$('s13_btn_Text2').animate({left: "214"},400);
         sym.$('s13_btn_underplay2').animate({left: "483", width:"400"},400);
         sym.$('s13_btn_underplaytext2').animate({left: "552"},400);
         sym.$('s13_btn_shadow2').animate({left: "125", width:"739"},400);
         sym.$('s13_play_glow2').hide();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 91500, function(sym, e) {
         sym.stop();
         anchor.act = sym;
         anchor.playFrom = 'slide14';
         anchor.playBack = 'slide12_back';

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 92500, function(sym, e) {
         sym.stop();
         anchor.act = sym;
         anchor.playFrom = 'slide15';
         anchor.playBack = 'slide13_back';

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 93500, function(sym, e) {
         sym.stop();
         anchor.act = sym;
         anchor.playFrom = 'slide1';
         anchor.playBack = 'slide14_back';

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 17250, function(sym, e) {
         sym.$('s5_percent').html('30%');
         sym.$('s5_percent2').html('20%');
         sym.$('s5_percent3').html('1%');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 6750, function(sym, e) {
         sym.$('s3_row_diag1_text').html('23%');
         sym.$('s3_row_diag2_text').html('15%');
         sym.$('s3_row2_diag3_text').html('10%');
         sym.$('s3_row2_diag4_text').html('5%');
         sym.$('s3_row3_diag5_text').html('5%');
         sym.$('s3_row3_diag6_text').html('1%');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 76250, function(sym, e) {
         sym.$('s13_btn_play').css({"left": "292px"});
         sym.$('s13_btn_Text').css({"left": "392px"});
         sym.$('s13_btn_underplay').css({"left": "320px", "width":"386px"});
         sym.$('s13_btn_underplaytext').css({"left": "369px"});
         sym.$('s13_btn_shadow').css({"left": "303px", "width":"406px"});
         
         sym.$('s13_btn_play2').css({"left": "292px"});
         sym.$('s13_btn_Text2').css({"left": "392px"});
         sym.$('s13_btn_underplay2').css({"left": "320px", "width":"386px"});
         sym.$('s13_btn_underplaytext2').css({"left": "369px"});
         sym.$('s13_btn_shadow2').css({"left": "303px", "width":"406px"});

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_s13_play_glow}", "click", function(sym, e) {
         sym.$('s13_btn_play').animate({left: "114"},400);
         sym.$('s13_btn_Text').animate({left: "214"},400);
         sym.$('s13_btn_underplay').animate({left: "483", width:"400"},400);
         sym.$('s13_btn_underplaytext').animate({left: "552"},400);
         sym.$('s13_btn_shadow').animate({left: "125", width:"739"},400);
         sym.$('s13_play_glow').hide();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_s13_play_glow2}", "click", function(sym, e) {
         sym.$('s13_btn_play2').animate({left: "114"},400);
         sym.$('s13_btn_Text2').animate({left: "214"},400);
         sym.$('s13_btn_underplay2').animate({left: "483", width:"400"},400);
         sym.$('s13_btn_underplaytext2').animate({left: "552"},400);
         sym.$('s13_btn_shadow2').animate({left: "125", width:"739"},400);
         sym.$('s13_play_glow2').hide();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 25000, function(sym, e) {
         sym.$('s7_nervi').css('background-image','url(media/images/nervi.png)');

      });
      //Edge binding end

   })("stage");
   //Edge symbol end:'stage'

})(jQuery, AdobeEdge, "EDGE-303870817");