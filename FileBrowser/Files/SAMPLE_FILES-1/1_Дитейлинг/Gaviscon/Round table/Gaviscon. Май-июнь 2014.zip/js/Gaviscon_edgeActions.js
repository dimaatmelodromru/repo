/***********************
* Adobe Edge Animate Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge Animate
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

   //Edge symbol: 'stage'
   (function(symbolName) {
      
      
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 0, function(sym, e) {
         function changeText(id,from, to) {
         	val = sym.$(id).html();
         	sym.$(id).html(val.replace(from,to));
         }
         changeText('s1_heading', '®','<sup>®</sup>');
         changeText('s1_text', '®','<sup>®</sup>');
         changeText('s5_heading', '®','<sup>®</sup>');
         changeText('s6_heading', '®','<sup>®</sup>');
         changeText('s6_heading', '*','<sup>*</sup>');
         changeText('s7_text', '®','<sup>®</sup>');
         changeText('s8_title', '®','<sup>®</sup>');
         changeText('s8_heading', '®','<sup>®</sup>');
         changeText('s6_text14', 'R','<sup>®</sup>');
         
         
         sym.$('s7_diag_1').css({
         "background-image": "url('media/images/diag_bg.jpg')",
         "background-repeat": "repeat-x",
         "background-position": "left bottom"
         });
         sym.$('s7_diag_2').css({
         "background-image": "url('media/images/diag_bg.jpg')",
         "background-repeat": "repeat-x",
         "background-position": "left bottom"
         });
         sym.$('s7_diag_3').css({
         "background-image": "url('media/images/diag_bg.jpg')",
         "background-repeat": "repeat-x",
         "background-position": "left bottom"
         });
         sym.$('s7_diag_4').css({
         "background-image": "url('media/images/diag_bg.jpg')",
         "background-repeat": "repeat-x",
         "background-position": "left bottom"
         });

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 5000, function(sym, e) {
         sym.stop();
         anchor.act = sym;
         anchor.playFrom = 'slide2';
         anchor.playBack = 'slide1';

      });
      //Edge binding end

      

      

      

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 14250, function(sym, e) {
         sym.stop();
         anchor.act = sym;
         anchor.playFrom = 'slide4';
         anchor.playBack = 'slide2_back';

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 17750, function(sym, e) {
         sym.$('s4_72').html('22%');
         

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 18000, function(sym, e) {
         sym.$('s4_72').html('32%');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 18250, function(sym, e) {
         sym.$('s4_72').html('44%');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 18500, function(sym, e) {
         sym.$('s4_72').html('47%');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 18750, function(sym, e) {
         sym.$('s4_72').html('52%');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 19000, function(sym, e) {
         sym.$('s4_72').html('57%');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 19250, function(sym, e) {
         sym.$('s4_72').html('62%');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 19750, function(sym, e) {
         sym.stop();
         anchor.act = sym;
         anchor.playFrom = 'slide5';
         anchor.playBack = 'slide3_back';
         
         sym.$('s4_72').html('72%');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 19500, function(sym, e) {
         sym.$('s4_72').html('67%');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 17867, function(sym, e) {
         sym.$('s4_72').html('27%');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 18130, function(sym, e) {
         sym.$('s4_72').html('37%');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 18372, function(sym, e) {
         sym.$('s4_72').html('47%');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 18623, function(sym, e) {
         sym.$('s4_72').html('50%');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 18880, function(sym, e) {
         sym.$('s4_72').html('54%');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 19118, function(sym, e) {
         sym.$('s4_72').html('60%');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 19375, function(sym, e) {
         sym.$('s4_72').html('64%');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 19626, function(sym, e) {
         sym.$('s4_72').html('70%');

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_play}", "click", function(sym, e) {
         sym.$('jeludok_state').css('background-image','url(media/images/jeludok_full.gif)');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 7500, function(sym, e) {
         sym.stop();
         anchor.act = sym;
         anchor.playFrom = 'slide3';
         anchor.playBack = 'slide1_back';
         
         

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 21250, function(sym, e) {
         sym.stop();
         anchor.act = sym;
         anchor.playFrom = 'slide6';
         anchor.playBack = 'slide4_back';

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 28750, function(sym, e) {
         sym.stop();
         anchor.act = sym;
         anchor.playFrom = 'slide7';
         anchor.playBack = 'slide5_back';

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 36250, function(sym, e) {
         sym.stop();
         anchor.act = sym;
         anchor.playFrom = 'slide8';
         anchor.playBack = 'slide6_back';

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 44500, function(sym, e) {
         sym.stop();
         anchor.act = sym;
         anchor.playFrom = 'slide1';
         anchor.playBack = 'slide8_back';

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 42500, function(sym, e) {
         sym.stop();
         anchor.act = sym;
         anchor.playFrom = 'slide9';
         anchor.playBack = 'slide7_back';

      });
      //Edge binding end

      

      Symbol.bindElementAction(compId, symbolName, "${_bruho_state}", "click", function(sym, e) {
         anchor.act = '';
         sym.$('bruho_state').css('background-image','url(media/images/bruho_full.gif)');
         sym.play();
         clickBruho = true;

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_s2_circle}", "click", function(sym, e) {
         anchor.act = '';
         sym.$('bruho_state').css('background-image','url(media/images/bruho_full.gif)');
         sym.play();
         clickBruho = true;

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 10750, function(sym, e) {
         sym.stop();
         anchor.act = sym;
         anchor.playFrom = 'slide3';
         anchor.playBack = 'slide2_back';

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 9494, function(sym, e) {
         sym.$('bruho_state').hide();
         sym.$('s2_circle').hide();
         

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 12484, function(sym, e) {
         if (!clickBruho) {
         	sym.$('bruho_12').hide();
         	sym.$('bruho_22').hide();
         	sym.$('bruho_32').hide();
         	sym.$('bruho_42').hide();
         }

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 5500, function(sym, e) {
         sym.$('bruho_state').css('background-image','url(media/images/bruho_state_anim.gif)');

      });
      //Edge binding end

   })("stage");
   //Edge symbol end:'stage'

})(jQuery, AdobeEdge, "EDGE-1018555");